package com.example.myapplication2;

import androidx.appcompat.app.AppCompatActivity;

import android.media.audiofx.Visualizer;
import android.os.Bundle;

public class MainActivity2 extends AppCompatActivity {
    private static final String BROKER_URL = "broker.mqtt-dashboard.com";
    private static final String CLIENT_ID = "Evan8888";
    private MqttHandler MqttHandler;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        MqttHandler = new MqttHandler();
        MqttHandler.connect(BROKER_URL,CLIENT_ID);
    }

    @Override
    protected void onDestroy() {
        MqttHandler.disconnect();
        super.onDestroy();
    }

}